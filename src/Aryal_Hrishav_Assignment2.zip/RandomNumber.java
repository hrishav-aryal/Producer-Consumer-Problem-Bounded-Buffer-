
public class RandomNumber {
	
	public static int randomInteger(int k) {
		return (int)(k * Math.random());
	}

}
